# XOR_array

## Script

* four neurons in hidden layer (one hidden layer)
* one  neuron in output layer (one output)

* Note : Need to change DATA_STORE_PATH 

在 openfile.h 中切換 inculde 的 def_2bit.h 跟 def_3bit.h 可以做 XOR 不同 input 的轉換分析
  > def_2bit.h 為 input＝2 <br />
  > def_3bit.h 為 input＝3
