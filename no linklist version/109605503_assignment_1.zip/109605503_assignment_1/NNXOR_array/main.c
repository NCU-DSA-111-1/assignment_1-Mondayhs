#include "simulate.h"



int main()
{

    read_input_data();        //call function to read XOR data file contents
    simulate_net();           //call function to simulate network
    
    return 0;

}